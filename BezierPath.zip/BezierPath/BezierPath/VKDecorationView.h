//
//  VKDecorationView.h
//  VK
//
//  Created by sctengsen-imac03 on 16/7/27.
//  Copyright © 2016年 sctengsen-ZJB. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VKDecorationView : UICollectionReusableView

@end
