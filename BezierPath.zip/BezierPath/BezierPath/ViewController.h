//
//  ViewController.h
//  BezierPath
//
//  Created by sctengsen-imac03 on 16/8/12.
//  Copyright © 2016年 sctengsen-ZJB. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

CGFloat getValue(CGFloat value);
@end

