//
//  MainCollectionViewCell.h
//  VK
//
//  Created by sctengsen-imac03 on 16/7/27.
//  Copyright © 2016年 sctengsen-ZJB. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainCollectionViewCell : UICollectionViewCell
@property(nonatomic,strong)UILabel*songsName;
@property(nonatomic,strong)UILabel*nickName;
@property(nonatomic,strong)UILabel*scoreLabel;
@property(nonatomic,strong)UILabel*haveListenedlabel;
@property(nonatomic,strong)UIImageView*iconImage;
-(void)setValue;
@end
