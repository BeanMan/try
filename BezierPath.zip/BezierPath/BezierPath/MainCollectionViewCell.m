//
//  MainCollectionViewCell.m
//  VK
//
//  Created by sctengsen-imac03 on 16/7/27.
//  Copyright © 2016年 sctengsen-ZJB. All rights reserved.
//

#import "MainCollectionViewCell.h"


@implementation MainCollectionViewCell

-(instancetype)initWithFrame:(CGRect)frame{
    
    if (self ==[super initWithFrame:frame]) {
       
        UIFont*font = [UIFont systemFontOfSize:11];
        self.songsName = [[UILabel alloc]initWithFrame:CGRectMake(0, getValue(20), self.frame.size.width, getValue(25))];
        self.songsName.font = font;
        self.songsName.textAlignment = 1;
        self.songsName.textColor = TextColor;
        self.songsName.adjustsFontSizeToFitWidth = YES;
        self.songsName.text = @"I CHOOSE YOU";
        [self.contentView addSubview:self.songsName];
        //
        self.nickName = [[UILabel alloc]initWithFrame:CGRectMake(0, getValue(20+25), self.frame.size.width, getValue(22))];
        self.nickName.font = font;
        self.nickName.textAlignment = 1;
        self.nickName.text =@"富顺火龙王";
        self.nickName.textColor = TextColor;
        self.nickName.adjustsFontSizeToFitWidth = YES;
        [self.contentView addSubview:self.nickName];
        //
        self.scoreLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, getValue(20+50), self.frame.size.width, getValue(22))];
        self.scoreLabel.font = font;
        self.scoreLabel.textAlignment = 1;
        self.scoreLabel.text = @"99分";
        self.scoreLabel.textColor = RGB(242, 140, 40);
        self.scoreLabel.adjustsFontSizeToFitWidth = YES;
        [self.contentView addSubview:self.scoreLabel];
        //
        self.haveListenedlabel = [[UILabel alloc]initWithFrame:CGRectMake(0, getValue(20+75), self.frame.size.width, getValue(22))];
        self.haveListenedlabel.font = font;
        self.haveListenedlabel.textAlignment = 1;
        self.haveListenedlabel.text = @"617014";
        self.haveListenedlabel.textColor = RGB(98, 110, 120);
        self.haveListenedlabel.adjustsFontSizeToFitWidth = YES;
        [self.contentView addSubview:self.haveListenedlabel];
        
        self.iconImage = [[UIImageView alloc]initWithFrame:CGRectMake(0, getValue(130), getValue(160), getValue(174))];
        [self.iconImage getHexagonImageViewWithLineWidth:5 Side:6 CornerRadius:getValue(25) RotationOffset:M_PI /6.0];
//        self.iconImage.backgroundColor = [UIColor blueColor];
        self.iconImage.contentMode = UIViewContentModeScaleToFill;
        self.iconImage.image = [UIImage imageNamed:@"1.jpg"];
        [self.contentView addSubview:self.iconImage];
        
    }
    
    return self;
}
-(void)setValue{
    
}
@end
