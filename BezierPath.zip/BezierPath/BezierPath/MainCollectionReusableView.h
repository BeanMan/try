//
//  MainCollectionReusableView.h
//  VK
//
//  Created by sctengsen-imac03 on 16/7/28.
//  Copyright © 2016年 sctengsen-ZJB. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol SectionHeaderDelegate<NSObject>
-(void)clickHeadButtonWithTag:(NSInteger)tag;
@end
@interface MainCollectionReusableView : UICollectionReusableView<UIScrollViewDelegate>

@property(nonatomic,strong)UIView*headView;
@property(nonatomic,strong)UIImageView*iconImage;
@property(nonatomic,strong)UILabel*nameLabel;
@property(nonatomic,strong)UIView*buttonView;
@property(nonatomic,strong)UIScrollView*scrollView;
@property(nonatomic,strong)UIPageControl*page;
@property(nonatomic,weak)id<SectionHeaderDelegate>delegate;
@end
