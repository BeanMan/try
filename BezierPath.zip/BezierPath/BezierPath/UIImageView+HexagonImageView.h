//
//  UIImageView+HexagonImageView.h
//  VK
//
//  Created by sctengsen-imac03 on 16/8/13.
//  Copyright © 2016年 sctengsen-ZJB. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImageView (HexagonImageView)
-(void)getHexagonImageViewWithLineWidth:(CGFloat)lineWidth Side:(NSInteger)sides CornerRadius:(CGFloat)cornerRadius RotationOffset:(CGFloat)rotationOffset;
@end
