//
//  VKLayout.m
//  VK
//
//  Created by sctengsen-imac03 on 16/7/27.
//  Copyright © 2016年 sctengsen-ZJB. All rights reserved.
//

#import "VKLayout.h"
#import "VKDecorationView.h"

@implementation VKLayout
-(void)prepareLayout{
    [super prepareLayout];
    
    //注册 装饰视图
    [self registerClass:[VKDecorationView class] forDecorationViewOfKind:@"VK"];
   
}

//装饰视图布局
//Decoration View的布局
- (UICollectionViewLayoutAttributes *)layoutAttributesForDecorationViewOfKind:(NSString*)decorationViewKind atIndexPath:(NSIndexPath *)indexPath
{
    UICollectionViewLayoutAttributes *attributes = [UICollectionViewLayoutAttributes layoutAttributesForDecorationViewOfKind:decorationViewKind withIndexPath:indexPath];
    //285 本来应该是300 装饰图片上面截图有15的间隙
    attributes.frame = CGRectMake((KWIDTH-getValue(628))/2, getValue(285+330)+getValue(300+58)* indexPath.item, getValue(628), getValue(58));
    attributes.zIndex = -1;
    
    return attributes;
}
-(UICollectionViewLayoutAttributes*)layoutAttributesForSupplementaryViewOfKind:(NSString *)elementKind atIndexPath:(NSIndexPath *)indexPath{
    UICollectionViewLayoutAttributes*attribute = [UICollectionViewLayoutAttributes layoutAttributesForSupplementaryViewOfKind:elementKind withIndexPath:indexPath];
    
    if ([elementKind isEqualToString:UICollectionElementKindSectionHeader]) {
        attribute.size = CGSizeMake(KWIDTH, getValue(330));
        attribute.center = CGPointMake((CGFloat)KWIDTH/2,(CGFloat) getValue(330)/2);
         return attribute;
    }else{
        
        return nil;
    }
    
    
   
}

//进来就走这个方法
- (NSArray *)layoutAttributesForElementsInRect:(CGRect)rect
{
    NSMutableArray *array = [NSMutableArray array];
    NSInteger count = [self.collectionView numberOfItemsInSection:0];
    
    
    //添加 supplementaryView

        NSIndexPath *indexPath = [NSIndexPath indexPathForItem:0 inSection:0];
        UICollectionViewLayoutAttributes *attributes = [self layoutAttributesForSupplementaryViewOfKind:UICollectionElementKindSectionHeader atIndexPath:indexPath];
        [array addObject:attributes];
    
    
    // 添加decoration
    
    CGFloat j = count%3;
    if (j>0) {
        j=count/3+1;
    }else{
        j = count/3;
    }
    for (int i = 0; i < j; i++) {
        NSIndexPath *indexPath = [NSIndexPath indexPathForItem:i inSection:0];
        [array addObject:[self layoutAttributesForDecorationViewOfKind:@"VK"atIndexPath:indexPath]];
    }
    //添加cell
    for (int i = 0; i < count; i++) {
        NSIndexPath *indexPath = [NSIndexPath indexPathForItem:i inSection:0];
        [array addObject:[self layoutAttributesForItemAtIndexPath:indexPath]];
    }
    
    return array;
}

@end
