//
//  MainCollectionReusableView.m
//  VK
//
//  Created by sctengsen-imac03 on 16/7/28.
//  Copyright © 2016年 sctengsen-ZJB. All rights reserved.
//

#import "MainCollectionReusableView.h"
typedef NS_ENUM(NSInteger,ButtonTag){
    UINavigationItem_left,
    UINavigationItem_right,
    WORKS_TAG,
    COLLECTION_TAG,
    ALBUM_TAG,
    ACCOUNT_TAG
    
};
@implementation MainCollectionReusableView

- (void)awakeFromNib {
    [super awakeFromNib];
    
}

-(UIView*)headView{
    
    if (_headView==nil) {
        
        _headView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, KWIDTH, getValue(130))];
        _headView.backgroundColor = RGB(24, 28, 31);
        
        self.iconImage = [UIImageView new];
        self.iconImage.frame = CGRectMake(getValue(20), getValue(15), getValue(90), getValue(100));
        self.iconImage.backgroundColor = [UIColor redColor];
        [self.iconImage getHexagonImageViewWithLineWidth:3 Side:6 CornerRadius:getValue(15) RotationOffset:M_PI/6];
        self.iconImage.image = [UIImage imageNamed:@"1.jpg"];
        self.iconImage.userInteractionEnabled = YES;
        [self.iconImage addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapImage)]];
        self.iconImage.tag = 1;
        [_headView addSubview:self.iconImage];
        
        //
        
        self.nameLabel = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(_iconImage.frame)+getValue(40), getValue(30), getValue(320), getValue(44))];
        self.nameLabel.text = @"JACK CHENG";
        self.nameLabel.font = [UIFont systemFontOfSize:14];
        self.nameLabel.textColor = TextColor;
        [_headView addSubview:self.nameLabel];
        
        
    }
    
    
    return _headView;
}
-(UIPageControl*)page{
    if (_page ==nil) {
        _page = [UIPageControl new];
        _page.numberOfPages = 5;
        _page.currentPage = 0;
        _page.currentPageIndicatorTintColor = RGB(246, 157, 39);
        _page.pageIndicatorTintColor = [UIColor whiteColor];
        _page.frame = CGRectMake((CGFloat)(KWIDTH-getValue(120))/2, getValue(300), getValue(120), getValue(20));
    }
    
    return _page;
}
-(instancetype)initWithFrame:(CGRect)frame{
    
    if (self = [super initWithFrame: frame]) {
        
        //
        
        self.userInteractionEnabled = YES;

    //
        
        self.scrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, getValue(130), KWIDTH, getValue(190))];
        self.scrollView.contentSize =CGSizeMake(KWIDTH*5, getValue(190));
        self.scrollView.contentOffset = CGPointZero;
        self.scrollView.delegate = self;
        self.scrollView.pagingEnabled = YES;
        self.scrollView.bounces = NO;
        self.scrollView.showsHorizontalScrollIndicator = NO;
        self.scrollView.userInteractionEnabled = YES;
        [self addSubview:self.scrollView];
        [self addSubview:self.page];
       
       //
        //
        
        self.buttonView = [[UIView alloc]initWithFrame:CGRectMake(0, getValue(130-60), KWIDTH, getValue(60))];
     
        self.buttonView.backgroundColor = RGB(24, 28, 31);
        self.buttonView.userInteractionEnabled  = YES;
        [self addSubview:self.buttonView];
        
        {
            [self creatButtonWithframe:CGRectMake(0, 0, (CGFloat)KWIDTH/4-1, getValue(60)) AndTitle:@"作品" AndTag:WORKS_TAG];
            [self creatButtonWithframe:CGRectMake((CGFloat)KWIDTH/4, 0, (CGFloat)KWIDTH/4-1, getValue(60)) AndTitle:@"收藏" AndTag:COLLECTION_TAG];
            [self creatButtonWithframe:CGRectMake((CGFloat)KWIDTH/4*2, 0, (CGFloat)KWIDTH/4-1, getValue(60)) AndTitle:@"相册" AndTag:ALBUM_TAG];
            [self creatButtonWithframe:CGRectMake((CGFloat)KWIDTH/4*3, 0, (CGFloat)KWIDTH/4, getValue(60)) AndTitle:@"账户" AndTag:ACCOUNT_TAG];
            
        }
        
        [self addSubview:self.headView];
        
    }
    
    return self;
}
-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    
    int i = scrollView.contentOffset.x/KWIDTH;
    _page.currentPage = i;
    
}
-(void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate{
    
}
-(void)creatButtonWithframe:(CGRect)frame AndTitle:(NSString*)title AndTag:(NSInteger)tag{
    UIButton*button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setTitle:title forState:UIControlStateNormal];
    [button setTitleColor:TextColor forState:UIControlStateNormal];
    button.frame = frame;
    button.tag = tag;
    button.backgroundColor = NavColor;
     button.titleLabel.font = [UIFont systemFontOfSize:12];
    [button addTarget:self action:@selector(buttonClick:) forControlEvents:UIControlEventTouchUpInside];
     [self.buttonView addSubview:button];
}
-(void)tapImage{
    
    if (self.iconImage.tag==1) {
        //下拉
        [UIView animateWithDuration:0.5 animations:^{
            self.buttonView.frame = CGRectMake(0, getValue(130), KWIDTH, getValue(60));
        }];
        
        self.iconImage.tag = 2;
        
    }else{
        //收起
        [UIView animateWithDuration:0.5 animations:^{
           
          self.buttonView.frame = CGRectMake(0, getValue(130-60), KWIDTH, getValue(60));
        }];
        
        self.iconImage.tag = 1;
    }
    
    
}

-(void)buttonClick:(UIButton*)button
{
    if ([self.delegate respondsToSelector:@selector(clickHeadButtonWithTag:)]) {
        
        [self.delegate clickHeadButtonWithTag:button.tag];
    }else{
        
        NSLog(@"没有遵循代理");
    }

}
@end
