//
//  VKDecorationView.m
//  VK
//
//  Created by sctengsen-imac03 on 16/7/27.
//  Copyright © 2016年 sctengsen-ZJB. All rights reserved.
//

#import "VKDecorationView.h"

@implementation VKDecorationView
- (id)initWithFrame:(CGRect)frame

{
    self = [super initWithFrame:frame];
    
    if (self) {
        UIImageView*imageV  = [[UIImageView alloc]initWithFrame:self.bounds];
        imageV.image = [UIImage imageNamed:@"置物台1.png"];
        [self addSubview:imageV];

    }
    
    return self;
    
}
@end
