//
//  ViewController.m
//  BezierPath
//
//  Created by sctengsen-imac03 on 16/8/12.
//  Copyright © 2016年 sctengsen-ZJB. All rights reserved.
//

#import "ViewController.h"
#import "VKLayout.h"
#import "MainCollectionViewCell.h"
#import "MainCollectionReusableView.h"


#define collectionViewCellidentify @"mainCellIdentify"
typedef NS_ENUM(NSInteger,ButtonTag){
    UINavigationItem_left,
    UINavigationItem_right,
    WORKS_TAG,
    COLLECTION_TAG,
    ALBUM_TAG,
    ACCOUNT_TAG
    
};
@interface ViewController ()<UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout,SectionHeaderDelegate>
@property(strong,nonatomic)UICollectionView*collectionView;
@end

@implementation ViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    [self setUpNavigationBar];
    [self creatCollectionView];
}
CGFloat getValue(CGFloat value){
    CGFloat proportion = 0.0;
    
    
    
    if (KWIDTH==320.00) {
        //5和5s
        proportion = 2;
        
        
    }
    if (KWIDTH==375) {
        //6
        
        proportion = 1.71;
        
    }
    if (KWIDTH==414) {
        //6p
        
        proportion = 1.55;
    }
    
    CGFloat actualValue =(CGFloat) value/proportion;
    
    return actualValue;
}
-(void)creatCollectionView{
    //
    VKLayout*layout = [[VKLayout alloc]init];
    self.collectionView = [[UICollectionView alloc]initWithFrame:CGRectMake(0,0, KWIDTH, KEIGHT) collectionViewLayout:layout];
    layout.headerReferenceSize = CGSizeMake(KWIDTH, getValue(330));
    [self.collectionView setCollectionViewLayout:layout];
    self.collectionView.showsVerticalScrollIndicator = NO;
    self.collectionView.backgroundColor = RGB(24, 28, 31);
    self.collectionView.delegate = self;
    self.collectionView.dataSource = self;
    
    // Register cell classes
    [self.collectionView registerClass:[MainCollectionViewCell class] forCellWithReuseIdentifier:collectionViewCellidentify];
    //register 头部视图
    [self.collectionView registerClass:[MainCollectionReusableView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"head"];
    [self.view addSubview:self.collectionView];
    
}
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    
    return 20;
}
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    
    return 1;
}
-(UICollectionViewCell*)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    MainCollectionViewCell*cell = [collectionView dequeueReusableCellWithReuseIdentifier:collectionViewCellidentify forIndexPath:indexPath];
    
    cell.contentView.backgroundColor = [UIColor clearColor];
    
    return  cell;
    
}
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake(getValue(160), getValue(300));
}

//cell的最小行间距
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section
{
    return getValue(58);
}
//最小列间距
-(CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section{
    
    return getValue(30);
}
//margin
-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(0, getValue(50), 0, getValue(50));
}

- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath{
    
    MainCollectionReusableView *headerView = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"head" forIndexPath:indexPath];
    if (headerView==nil) {
        
        headerView = [[MainCollectionReusableView alloc]init];
    }
    
    headerView.delegate = self;
    
    
    return headerView;
}

-(void)setUpNavigationBar{
    self.navigationController.navigationBar.barTintColor = RGB(31, 36, 41);
    UIButton*left = [UIButton buttonWithType:UIButtonTypeCustom];
    [left setImage:[UIImage imageNamed:@"arrow_left"] forState:UIControlStateNormal];
    left.frame = CGRectMake(0, 0, 30, 22);
    left.imageEdgeInsets = UIEdgeInsetsMake(0, 0, 0, 15);
    left.tag = UINavigationItem_left;
    [left setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:left];
    //
    UIButton*right = [UIButton buttonWithType:UIButtonTypeCustom];
    [right setTitle:@"二维码" forState:UIControlStateNormal];
    right.frame = CGRectMake(0, 0, 80, 44);
    right.tag = UINavigationItem_right;
    [right setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:right];
    
}
#pragma mark 跳转
-(void)clickHeadButtonWithTag:(NSInteger)tag{
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
